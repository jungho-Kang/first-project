function MyPlanList() {
  return <div>마이페이지 일정목록</div>;
}

export default MyPlanList;
