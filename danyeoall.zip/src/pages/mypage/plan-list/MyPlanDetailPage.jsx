function MyPlanDetail() {
  return <div>내 일정 디테일 페이지</div>;
}

export default MyPlanDetail;
