function IndexPage() {
  return <div>프로필 페이지</div>;
}

export default IndexPage;
