function UpdatePwPage() {
  return <div>비밀번호 재설정</div>;
}

export default UpdatePwPage;
