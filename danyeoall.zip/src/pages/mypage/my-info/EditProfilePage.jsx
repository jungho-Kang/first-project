function EditProfilePage() {
  return <div>프로필 수정페이지</div>;
}

export default EditProfilePage;
