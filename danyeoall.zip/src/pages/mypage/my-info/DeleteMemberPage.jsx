function DeleteMemberPage() {
  return <div>회원탈퇴 페이지</div>;
}

export default DeleteMemberPage;
