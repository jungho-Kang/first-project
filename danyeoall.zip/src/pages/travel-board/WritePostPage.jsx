function WritePostPage() {
  return <div>게시판 작성/수정 페이지</div>;
}

export default WritePostPage;
