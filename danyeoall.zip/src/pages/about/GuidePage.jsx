function GuidePage() {
  return <div>이용방법 페이지</div>;
}

export default GuidePage;
