function IndexPage() {
  return <div>사이트 소개</div>;
}

export default IndexPage;
