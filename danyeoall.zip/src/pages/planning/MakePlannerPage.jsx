function MakePlannerPage() {
  return <div>일정계획 페이지</div>;
}
export default MakePlannerPage;
