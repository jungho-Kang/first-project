import styled from "@emotion/styled";
import BasicBtn from "../../components/button/BasicBtn";
import { JoinDiv, WrapDiv } from "../../components/common";
import CustomCheck from "../../components/input/CustomCheck";
import LayerLogo from "../../components/layer/LayerLogo";
import CustomInput from "../../components/input/CustomInput";
import CustomInputBtn from "../../components/input/CustomInputBtn";
import { Link } from "react-router-dom";

const AgreementDiv = styled.div`
  border: 1px solid #eee;
  max-width: 1024px;
  height: 100vh;
  margin: 0 auto;
  display: flex;
  gap: 15px;
  flex-direction: column;
  padding: 60px 100px 100px;

  h2 {
    font-size: 28px;
    font-weight: 700;
  }
`;
const AgreementDocumentDiv = styled.div`
  border: 1px solid #dbdbdb;
  padding: 30px;
  line-height: 1.35em;
`;

function SignupPage() {
  return (
    <div>
      <WrapDiv>
        {/* 동의서 */}
        {/* <AgreementDiv>
          <LayerLogo />
          <h2>다녀올 회원약관동의</h2>

          <BasicBtn
            btnname={"네 모두 동의 합니다."}
            Bg={"#eee"}
            color={"#777"}
            mt={"20px"}
          />
          <CustomCheck label={"agree01"} text={"본인은 만 14세 이상입니다"} />
          <CustomCheck label={"agree02"} text={"개인정보 수집에 동의합니다"} />
          <AgreementDocumentDiv>
            <p>Lorem ipsum dolor sit amet.</p>
            <span>
              Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sed
              nesciunt similique veritatis. Facilis non nihil aperiam reiciendis
              perferendis veritatis deserunt optio blanditiis. Nobis distinctio
              fuga consequuntur velit quasi. Magni, eaque.
            </span>
          </AgreementDocumentDiv>
          <CustomCheck label={"agree03"} text={"이용약관에 동의합니다"} />
          <AgreementDocumentDiv>
            <p>Lorem ipsum dolor sit amet.</p>
            <span>
              Lorem ipsum dolor sit amet consectetur, adipisicing elit. Sed
              nesciunt similique veritatis. Facilis non nihil aperiam reiciendis
              perferendis veritatis deserunt optio blanditiis. Nobis distinctio
              fuga consequuntur velit quasi. Magni, eaque.
            </span>
          </AgreementDocumentDiv>
          <BasicBtn btnname={"다음"} />
        </AgreementDiv> */}

        {/* 회원가입 */}
        <AgreementDiv style={{ padding: "60px 200px 100px" }}>
          <LayerLogo />
          <h2>회원가입</h2>
          <div className="form">
            <CustomInput label={"NickName"} type={"text"} />
            <CustomInput label={"Name"} type={"text"} />
            <CustomInputBtn
              label={"Email"}
              type={"email"}
              btntxt={"인증번호"}
            />
            <CustomInputBtn label={"인증코드"} type={"text"} btntxt={"확인"} />
            <CustomInput label={"Password"} type={"password"} />
            <CustomInput label={"Password 확인"} type={"password"} />
            <BasicBtn btnname={"확인"} />
            <JoinDiv>
              <Link to={"/auth"}>로그인화면 이동</Link>
            </JoinDiv>
          </div>
        </AgreementDiv>
      </WrapDiv>
    </div>
  );
}

export default SignupPage;
